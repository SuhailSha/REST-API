package com.suhailrestproject.restapi;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Country {
	
private String CountryCode;
public String getCountryCode() {
	return CountryCode;
}
public void setCountryCode(String countryCode) {
	CountryCode = countryCode;
}
private String CountryName;
public String getCountryName() {
	return CountryName;
}
public void setCountryName(String countryName) {
	CountryName = countryName;
}
private String CurrencyCode;
public String getCurrencyCode() {
	return CurrencyCode;
}
public void setCurrencyCode(String currencyCode) {
	CurrencyCode = currencyCode;
}
private String CountryDateFormat;
public String getCountryDateFormat() {
	return CountryDateFormat;
}
public void setCountryDateFormat(String countryDateFormat) {
	CountryDateFormat = countryDateFormat;
}
private int ResponseCode =999;
private String ResponseDescription = "FAILURE";
public int getResponseCode() {
	return ResponseCode;
}
public void setResponseCode(int responseCode) {
	ResponseCode = responseCode;
}
public String getResponseDescription() {
	return ResponseDescription;
}
public void setResponseDescription(String responseDescription) {
	ResponseDescription = responseDescription;
}

private String CountryDate;
 //=dtf.format(now);
public String getCountryDate() {
	return CountryDate;
}
public void setCountryDate(String countryDate) {
	CountryDate = countryDate;
}

//System.out.println(strDate);


}
