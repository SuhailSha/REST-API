package com.suhailrestproject.restapi;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class CountryRepository

{

	List<Country> country;
	
	public CountryRepository() {
	
		country =new ArrayList<Country>();
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MMM/YY");
		LocalDate now = LocalDate.now();
		String strDate=dtf.format(now);
				Country c1=new Country();
				c1.setCountryCode("SG");
				c1.setCountryDateFormat("dd/MMM/YY");
				c1.setCountryDate(strDate);
				c1.setCountryName("Singapore");
				c1.setCurrencyCode("SGD");
				c1.setResponseCode(0);
				c1.setResponseDescription("SUCCESS");
				
				
				
				DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("YYYY/MM/dd");
				LocalDate now1 = LocalDate.now();
				String strDate1=dtf1.format(now1);
						Country c2=new Country();
						c2.setCountryCode("AU");
						c2.setCountryDateFormat("YYYY/MM/DD");
						c2.setCountryDate(strDate1);
						c2.setCountryName("Australia");
						c2.setCurrencyCode("AUD");
						c2.setResponseCode(0);
						c2.setResponseDescription("SUCCESS");
						
						
		country.add(c1);
		country.add(c2);
		
	}
	public List<Country> getCountry()
	
	{
		return country;
	}

	public Country getCountry(String code)
	
	{
String code1=code.toUpperCase();
	
	//	System.out.println(code);
		
	
		for(Country c : country) {
			
		//	System.out.println(code+" "+c+" "+c.getCountryCode());
			
			if(c.getCountryCode().equals(code1)) {
			//System.out.println(code+" "+c+" "+c.getId());
				//System.out.println(code);
				return c;
			}
		
		}
		return new Country();
	}
	
}


