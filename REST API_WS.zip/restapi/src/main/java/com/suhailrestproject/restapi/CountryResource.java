package com.suhailrestproject.restapi;


import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("CountryDetails")
public class CountryResource 
{

	
	CountryRepository repo = new CountryRepository();
	
@GET
@Produces({MediaType.APPLICATION_XML})  //MediaType.APPLICATION_JSON,
	public List<Country> getCountry() {
				 
				return repo.getCountry();
		
	}


@GET
@Path("CountryDetails/{code}")
@Produces({MediaType.APPLICATION_XML})  //MediaType.APPLICATION_JSON,
	public Country getCountry(@PathParam("code") String code) {   
				 
				return repo.getCountry(code);
		
	}
	


}
